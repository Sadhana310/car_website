from flask import Flask, render_template, request
import json

app = Flask(__name__)

with open('data/cars.json', 'r') as f:
    cars = json.load(f)

@app.route('/')
def index():
    return render_template('index.html', cars=cars)

@app.route('/car/<int:car_id>')
def car_detail(car_id):
    car = next((c for c in cars if c['id'] == car_id), None)
    return render_template('car_detail.html', car=car)

@app.route('/compare')
def compare():
    ids = request.args.getlist('id', type=int)
    selected = [c for c in cars if c['id'] in ids]
    return render_template('compare.html', cars=selected)

if __name__ == '__main__':
    app.run(debug=True)